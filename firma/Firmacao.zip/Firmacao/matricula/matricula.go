package matricula

type Matricula struct {
	IdFormando string
	Curso      string
	Regime     string
}

func (m *Matricula) MatricularFormando(idFormando, c, r string) {
	m.IdFormando = idFormando
	m.Curso = c
	m.Regime = r
	// implementar o save que pode ser implementado na prórpia máquina

}

// fazendo save essa função é substituida
func (m Matricula) MostraEstudaMatriculado(idFormando string) Matricula {
	if m.IdFormando == idFormando {
		return m
	}

	return Matricula{}
}
